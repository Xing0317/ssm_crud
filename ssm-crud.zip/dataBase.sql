SELECT
e.emp_id, e.emp_name, e.gender, e.email, e.d_id, d.dept_id, d.dept_name
FROM tbl_emp e LEFT JOIN tbl_dept d
 ON e.`d_id` = d.`dept_id`
 
SELECT COUNT(*) FROM tbl_emp

DELETE  FROM tbl_emp WHERE emp_id > 2

SELECT * FROM tbl_emp WHERE emp_id > 2613