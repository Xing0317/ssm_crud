import com.heng.dao.DepartmentMapper;
import com.heng.dao.EmployeeMapper;
import com.heng.pojo.Department;
import com.heng.pojo.Employee;
import org.apache.ibatis.session.SqlSession;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.UUID;

/**
 * @author xingluheng
 * @date 2021/9/9 16:15)
 * 测试DAO层的工作
 * * 推荐使用Spring的单元测试
 * 导入Spring的测试模块
 * 直接用AtuoWire自动注入就行
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:applicationContext.xml"})
public class MapperTest {

    /*
    * 测试Department
    *
    */
    @Autowired
    DepartmentMapper departmentMapper;
    @Autowired
    EmployeeMapper employeeMapper;
    @Autowired
    SqlSession sqlSession;
    @Test
    public void test(){
        System.out.println(departmentMapper);

//        //插入几个部门
//        departmentMapper.insert(new Department(null,"开发部"));
//        departmentMapper.insertSelective(new Department(null,"测试部"));
//        departmentMapper.insertSelective(new Department(null,"人事部"));
//        departmentMapper.insertSelective(new Department(null,"售后部"));

        //插入几个员工信息
        //employeeMapper.insertSelective(new Employee(null, "Jerry", "M", "Jerry@123.com", 1));

        //批量插入多个员工，批量插入可以执行操作的SqlSession
//        EmployeeMapper mapper = sqlSession.getMapper(EmployeeMapper.class);
//        for (int i = 0; i < 1000; i++) {
//            String uid = UUID.randomUUID().toString().substring(0,5)+i;
//            mapper.insertSelective(new Employee(null,uid,"M",uid+"@xingluheng.com",1));
//        }
//        System.out.println("批量执行完成");
    }
}
