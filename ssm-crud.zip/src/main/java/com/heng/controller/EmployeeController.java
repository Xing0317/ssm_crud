package com.heng.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.heng.pojo.Employee;
import com.heng.pojo.Msg;
import com.heng.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author xingluheng
 * @date 2021/9/10 13:15)
 * 处理员工的CRUD
 */
@Controller
public class EmployeeController {

    @Autowired
    EmployeeService employeeService;

    /*
    * 删除单个员工数据
    * */
    @ResponseBody
    @RequestMapping(value = "/emp/{id}",method = RequestMethod.DELETE)
    public Msg deleteEmpById(@PathVariable("id") Integer id){
        employeeService.deleteEmp(id);
        return Msg.success();
    }
    /*
    保存员工数据
    * */
    @RequestMapping(value = "/emp/{empId}",method = RequestMethod.PUT)
    @ResponseBody
    public Msg saveEmp(Employee employee){
//        System.out.println("将要更新的数据===>"+employee);
        employeeService.update(employee);
        return Msg.success();
    }
    /*
    * 根据id查询员工
    * */
    @RequestMapping(value = "/emp/{id}",method = RequestMethod.GET)
    @ResponseBody
    public Msg getEmp(@PathVariable Integer id){
        Employee employee = employeeService.getEmp(id);
        return Msg.success().add("emp",employee);
    }
    //检验用户名唯一
    @ResponseBody
    @RequestMapping("/checkUser")
    public Msg checkUser(@RequestParam("empName") String empName) {
        //        先判断用户名是否是合法的表达式，再判断是否重复
        String regx = "(^[a-zA-Z0-9_-]{6,16}$)|(^[\\u2E80-\\u9FFF]{2,5})";
        if(!empName.matches(regx)){
            return Msg.fail().add("va_msg", "用户名必须是6-16位数字，字母或者_-，也可以是2-5位中文组成");
        }else{
//            数据库用户名重复校验
            boolean b = employeeService.checkUser(empName);
            if(b){
                return Msg.success();
            }else{
                return Msg.fail().add("va_msg", "用户名已存在");
            }
        }
    }
    //员工添加
    @RequestMapping(value = "/emp",method = RequestMethod.POST)
    @ResponseBody
    public Msg saveEmployee(@Valid Employee employee, BindingResult result){
        if (result.hasErrors()) {
            //检验失败后 在模态框中希纳是检验失败的错误信息
            Map<String, Object> map = new HashMap<>();
            List<FieldError> fieldErrors = result.getFieldErrors();
            for (FieldError fieldError : fieldErrors) {
                System.out.println("错误的字段名"+fieldError.getField());
                System.out.println("错误信息"+fieldError.getDefaultMessage());
                map.put(fieldError.getField(),fieldError.getDefaultMessage());
            }
            return Msg.fail().add("errorFields",map);
        }else {
            employeeService.saveEmp(employee);
            return Msg.success();
        }
    }



    //查询员工数据
    @RequestMapping("/employs")
    public String getEmploys(@RequestParam(value = "pn",defaultValue = "1")Integer pn, Model model){
        //引入PageHelper插件
        //在查询之前需要引入,插入页码，以及每页的大小
        PageHelper.startPage(pn,5);
        //startPage后面就是分页查询
        //封装了
        List<Employee> list = employeeService.getAll();
        //使用pageInfo 传入连续显示的页数
        PageInfo<Employee> page = new PageInfo<>(list,5);
        model.addAttribute("pageInfo",page);
        return "list";
    }

    @RequestMapping("/employs1")
    @ResponseBody
    public Msg getEmpWithJson(@RequestParam(value = "pn",defaultValue = "1")Integer pn, Model model){
        //引入PageHelper插件
        //在查询之前需要引入,插入页码，以及每页的大小
        PageHelper.startPage(pn,5);
        //startPage后面就是分页查询
        //封装了
        List<Employee> list = employeeService.getAll();
        //使用pageInfo 传入连续显示的页数
        PageInfo<Employee> page = new PageInfo<>(list,5);
        return Msg.success().add("pageInfo",page);
    }
}
