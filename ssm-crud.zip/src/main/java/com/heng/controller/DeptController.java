package com.heng.controller;

import com.heng.pojo.Department;
import com.heng.pojo.Msg;
import com.heng.service.DepartmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

/**
 * @author xingluheng
 * @date 2021/9/12 9:39)
 * 处理和部门有关的请求
 */
@Controller
public class DeptController {

    @Autowired
    private DepartmentService departmentService;

    /*
    * 返回所有的部门信息
    * */

    @ResponseBody
    @RequestMapping("/dept")
    public Msg getDept(){
        //查出的所有部门信息
       List<Department> deptList =  departmentService.getDept();
        return Msg.success().add("dept",deptList);
    }
}
