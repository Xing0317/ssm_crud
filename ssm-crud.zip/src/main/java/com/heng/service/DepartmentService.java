package com.heng.service;

import com.heng.dao.DepartmentMapper;
import com.heng.pojo.Department;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author xingluheng
 * @date 2021/9/12 9:40)
 */

@Service
public class DepartmentService {

    @Autowired
    private DepartmentMapper departmentMapper;
    public List<Department> getDept() {
        List<Department> list = departmentMapper.selectByExample(null);
        return list;
    }
}
