package com.heng.service;

import com.heng.dao.EmployeeMapper;
import com.heng.pojo.Employee;
import com.heng.pojo.EmployeeExample;
import com.heng.pojo.Msg;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author xingluheng
 * @date 2021/9/10 13:19)
 */
@Service
public class EmployeeService {

    //查询所有员工
    @Autowired
    EmployeeMapper employeeMapper;
    public List<Employee> getAll(){
        return employeeMapper.selectByExampleWithDept(null);
    }


    //员工保存的方法
    public Msg saveEmp(Employee employee) {
        employeeMapper.insertSelective(employee);
        return Msg.success();
    }

    //检验用户名是否可用
    public Boolean checkUser(String empName) {
        EmployeeExample example = new EmployeeExample();
        EmployeeExample.Criteria criteria = example.createCriteria();
        criteria.andEmpNameEqualTo(empName);
        long count = employeeMapper.countByExample(example);
//        如果count=0，返回true
        return count == 0;
    }

    //按照员工ID查询员工
    public Employee getEmp(Integer id) {
        Employee employee = employeeMapper.selectByPrimaryKey(id);
        return employee;
    }

    //员工共的更新
    public void update(Employee employee) {
        employeeMapper.updateByPrimaryKeySelective(employee);
    }

    public void deleteEmp(Integer id) {
        employeeMapper.deleteByPrimaryKey(id);
    }
}
